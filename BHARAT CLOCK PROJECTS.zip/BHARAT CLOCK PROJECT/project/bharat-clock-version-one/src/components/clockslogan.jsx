let ClockSlogan = () => {
  return (
    <p className="lead">
      this is the clock that show the time in bharat at all time.
    </p>
  );
};

export default ClockSlogan;
